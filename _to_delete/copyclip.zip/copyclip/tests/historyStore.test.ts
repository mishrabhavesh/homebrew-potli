import { describe, it, expect, vi, beforeEach } from "vitest";

class FakeStore<T extends object> {
  store: T;
  constructor(opts: { defaults: T }) {
    this.store = { ...opts.defaults };
  }
  get<K extends keyof T>(key: K, fallback?: T[K]) {
    return this.store[key] ?? fallback;
  }
  set<K extends keyof T>(key: K, value: T[K]) {
    this.store[key] = value;
  }
}

vi.mock("electron-store", () => ({ default: FakeStore }));

const { historyStore } = await import("../src/main/history/historyStore");

describe("historyStore", () => {
  beforeEach(() => {
    historyStore.clear();
  });

  it("starts empty", () => {
    expect(historyStore.getAll()).toEqual([]);
  });

  it("adds an entry with a generated id and timestamp, newest first", () => {
    historyStore.add({ text: "first", rawText: "first", region: { width: 100, height: 40 }, engine: "tesseract", language: "eng" });
    historyStore.add({ text: "second", rawText: "second", region: { width: 100, height: 40 }, engine: "tesseract", language: "eng" });

    const items = historyStore.getAll();
    expect(items).toHaveLength(2);
    expect(items[0].text).toBe("second"); // most recent first
    expect(items[0].id).toBeTruthy();
    expect(new Date(items[0].createdAt).toString()).not.toBe("Invalid Date");
  });

  it("deletes an entry by id", () => {
    const item = historyStore.add({ text: "to-delete", rawText: "to-delete", region: { width: 1, height: 1 }, engine: "tesseract", language: "eng" });
    historyStore.delete(item.id);
    expect(historyStore.getAll().find((i) => i.id === item.id)).toBeUndefined();
  });

  it("clears all entries", () => {
    historyStore.add({ text: "a", rawText: "a", region: { width: 1, height: 1 }, engine: "tesseract", language: "eng" });
    historyStore.add({ text: "b", rawText: "b", region: { width: 1, height: 1 }, engine: "tesseract", language: "eng" });
    historyStore.clear();
    expect(historyStore.getAll()).toEqual([]);
  });

  it("notifies listeners with the updated list on add/delete/clear", () => {
    const listener = vi.fn();
    const unsubscribe = historyStore.onChange(listener);

    historyStore.add({ text: "x", rawText: "x", region: { width: 1, height: 1 }, engine: "tesseract", language: "eng" });
    expect(listener).toHaveBeenLastCalledWith(expect.arrayContaining([expect.objectContaining({ text: "x" })]));

    historyStore.clear();
    expect(listener).toHaveBeenLastCalledWith([]);

    unsubscribe();
  });

  it("keeps the raw (uncleaned) text alongside the cleaned text", () => {
    const item = historyStore.add({
      text: "Hello world",
      rawText: "Hello    world",
      region: { width: 1, height: 1 },
      engine: "tesseract",
      language: "eng"
    });
    expect(item.rawText).toBe("Hello    world");
    expect(item.text).toBe("Hello world");
  });
});
