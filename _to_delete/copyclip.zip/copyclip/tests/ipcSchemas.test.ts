import { describe, it, expect } from "vitest";
import {
  appSettingsSchema,
  partialSettingsSchema,
  captureRegionSchema,
  historyDeleteSchema,
  shortcutSetSchema,
  navigateSchema,
  parseOrThrow
} from "../src/shared/ipc/schemas";
import { DEFAULT_SETTINGS } from "../src/shared/types/settings";

describe("appSettingsSchema", () => {
  it("accepts the default settings object", () => {
    expect(() => appSettingsSchema.parse(DEFAULT_SETTINGS)).not.toThrow();
  });

  it("rejects a settings object with a wrong-typed field", () => {
    const bad = { ...DEFAULT_SETTINGS, theme: "purple" };
    expect(() => appSettingsSchema.parse(bad)).toThrow();
  });

  it("rejects a missing required field", () => {
    const { shortcut, ...rest } = DEFAULT_SETTINGS;
    expect(() => appSettingsSchema.parse(rest)).toThrow();
  });
});

describe("partialSettingsSchema", () => {
  it("accepts an empty object", () => {
    expect(() => partialSettingsSchema.parse({})).not.toThrow();
  });

  it("accepts a single valid field update", () => {
    expect(() => partialSettingsSchema.parse({ autoPaste: true })).not.toThrow();
  });

  it("rejects an unknown-shaped field even in a partial update", () => {
    expect(() => partialSettingsSchema.parse({ theme: 123 })).toThrow();
  });
});

describe("captureRegionSchema", () => {
  it("accepts a well-formed capture region", () => {
    const region = { x: 10, y: 20, width: 300, height: 150, displayId: 1 };
    expect(() => captureRegionSchema.parse(region)).not.toThrow();
  });

  it("rejects a zero or negative width/height (guards against degenerate captures)", () => {
    expect(() => captureRegionSchema.parse({ x: 0, y: 0, width: 0, height: 100, displayId: 1 })).toThrow();
    expect(() => captureRegionSchema.parse({ x: 0, y: 0, width: 100, height: -5, displayId: 1 })).toThrow();
  });

  it("rejects an absurdly large region (protects against a malicious/buggy renderer payload)", () => {
    expect(() => captureRegionSchema.parse({ x: 0, y: 0, width: 999999, height: 100, displayId: 1 })).toThrow();
  });
});

describe("historyDeleteSchema / shortcutSetSchema / navigateSchema", () => {
  it("rejects an empty id", () => {
    expect(() => historyDeleteSchema.parse({ id: "" })).toThrow();
  });

  it("rejects an empty accelerator string", () => {
    expect(() => shortcutSetSchema.parse({ accelerator: "" })).toThrow();
  });

  it("only accepts known route names", () => {
    expect(() => navigateSchema.parse({ route: "quick-capture" })).not.toThrow();
    expect(() => navigateSchema.parse({ route: "not-a-real-route" })).toThrow();
  });
});

describe("parseOrThrow", () => {
  it("throws a descriptive error including the validation message", () => {
    expect(() => parseOrThrow(historyDeleteSchema, { id: "" })).toThrow(/Invalid IPC payload/);
  });

  it("returns the parsed value on success", () => {
    expect(parseOrThrow(historyDeleteSchema, { id: "abc" })).toEqual({ id: "abc" });
  });
});
