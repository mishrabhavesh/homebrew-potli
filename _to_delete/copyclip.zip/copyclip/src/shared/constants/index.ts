export const APP_NAME = "CopyClip";

export const MAIN_WINDOW_DEFAULT_SIZE = { width: 960, height: 640 };
export const MAIN_WINDOW_MIN_SIZE = { width: 780, height: 520 };

/** How long the success/error toast stays visible in the overlay before auto-dismissing (ms). */
export const TOAST_AUTO_DISMISS_MS = 2200;

/** Max number of history items kept locally. Oldest entries are pruned beyond this. */
export const HISTORY_LIMIT = 500;

/** Modifier-only accelerators (e.g. just "Shift") are rejected — a shortcut needs a non-modifier key. */
export const MODIFIER_KEYS = new Set(["Control", "Ctrl", "Cmd", "Command", "CommandOrControl", "Alt", "Option", "Shift", "Super", "Meta"]);
