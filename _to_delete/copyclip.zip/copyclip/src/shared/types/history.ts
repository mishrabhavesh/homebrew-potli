export interface HistoryItem {
  id: string;
  /** Full cleaned OCR text */
  text: string;
  /** Original, unmodified OCR text (recoverable per spec even after cleanup) */
  rawText: string;
  /** ISO 8601 timestamp */
  createdAt: string;
  /** Width/height of the captured region, for display context only */
  region: { width: number; height: number };
  /** Which OCR engine produced this result */
  engine: string;
  /** Best-effort language used */
  language: string;
}

export interface HistoryState {
  items: HistoryItem[];
}
