import { create } from "zustand";
import type { HistoryItem } from "@shared/types/history";

interface HistoryState {
  items: HistoryItem[];
  loaded: boolean;
  load: () => Promise<void>;
  remove: (id: string) => Promise<void>;
  clear: () => Promise<void>;
  copyAgain: (id: string) => Promise<void>;
}

export const useHistoryStore = create<HistoryState>((set, get) => ({
  items: [],
  loaded: false,
  load: async () => {
    const items = await window.copyclip.history.getAll();
    set({ items, loaded: true });
  },
  remove: async (id) => {
    set({ items: get().items.filter((i) => i.id !== id) });
    await window.copyclip.history.delete(id);
  },
  clear: async () => {
    set({ items: [] });
    await window.copyclip.history.clear();
  },
  copyAgain: async (id) => {
    await window.copyclip.history.copyAgain(id);
  }
}));

if (typeof window !== "undefined" && window.copyclip) {
  window.copyclip.history.onChanged((items) => {
    useHistoryStore.setState({ items, loaded: true });
  });
}
