import React from "react";
import ReactDOM from "react-dom/client";
import "../styles/globals.css";
import { SelectionOverlay } from "./SelectionOverlay";
import { Toast } from "./Toast";

const params = new URLSearchParams(window.location.search);
const mode = params.get("mode");

function Root() {
  if (mode === "toast") {
    return (
      <Toast
        message={params.get("message") ?? ""}
        status={(params.get("status") as "success" | "error" | "info") ?? "success"}
      />
    );
  }

  const displayId = Number(params.get("displayId") ?? "0");
  const isActive = params.get("isActive") === "1";
  return <SelectionOverlay displayId={displayId} isActive={isActive} />;
}

ReactDOM.createRoot(document.getElementById("root")!).render(<Root />);
