import React, { useEffect, useState } from "react";
import { ShortcutBadge } from "../components/ShortcutBadge";
import { useSettingsStore } from "../stores/settingsStore";
import { useHistoryStore } from "../stores/historyStore";

export function QuickCapture() {
  const { settings } = useSettingsStore();
  const items = useHistoryStore((s) => s.items);
  const [justTriggered, setJustTriggered] = useState(false);

  useEffect(() => {
    const off = window.copyclip.capture.onResult(() => {
      setJustTriggered(true);
      setTimeout(() => setJustTriggered(false), 1400);
    });
    return off;
  }, []);

  const startCapture = async () => {
    await window.copyclip.window.minimize();
    await window.copyclip.capture.start();
  };

  return (
    <div className="mx-auto flex h-full max-w-2xl flex-col items-center justify-center px-8 py-10 text-center">
      <p className="section-label mb-4">{settings.shortcutPaused ? "Shortcut paused" : "Ready"}</p>

      <h1 className="text-[26px] font-semibold tracking-tight">Capture text from anywhere.</h1>
      <p className="mx-auto mt-3 max-w-sm text-[14px] leading-relaxed text-[#6b6b70] dark:text-[#9c9ca3]">
        Select any text on your screen and copy it instantly.
      </p>

      <button
        onClick={startCapture}
        disabled={settings.shortcutPaused}
        className="btn-primary mt-8 gap-2 px-6 py-3 text-[14px] disabled:opacity-30"
      >
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
          <rect x="3" y="5" width="18" height="14" rx="2.5" stroke="currentColor" strokeWidth="1.8" />
          <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.8" />
        </svg>
        Capture Text
      </button>

      <div className="mt-9 flex flex-col items-center gap-2">
        <span className="section-label">Keyboard shortcut</span>
        <ShortcutBadge accelerator={settings.shortcut} size="lg" />
      </div>

      <WorkflowStrip />

      {items.length > 0 && (
        <div className="mt-10 w-full">
          <p className="section-label mb-2 text-left">Most recent</p>
          <div className="panel flex items-center justify-between px-4 py-3 text-left">
            <div className="min-w-0">
              <p className="truncate text-[13px] font-medium">{items[0].text.split("\n")[0] || "—"}</p>
              <p className="mt-0.5 text-[11.5px] text-[#9c9ca3]">{formatRelative(items[0].createdAt)}</p>
            </div>
          </div>
        </div>
      )}

      {justTriggered && (
        <div className="mt-4 animate-fade-in text-[12px] text-accent">Capture complete — check your clipboard</div>
      )}
    </div>
  );
}

function WorkflowStrip() {
  const steps = ["Press shortcut", "Drag to select", "Text copied"];
  return (
    <div className="mt-10 flex items-center gap-2 text-[11.5px] text-[#9c9ca3]">
      {steps.map((s, i) => (
        <React.Fragment key={s}>
          <span className="rounded-full border border-border-light px-2.5 py-1 dark:border-border-dark">{s}</span>
          {i < steps.length - 1 && <span className="opacity-50">→</span>}
        </React.Fragment>
      ))}
    </div>
  );
}

function formatRelative(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} minute${mins === 1 ? "" : "s"} ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} hour${hrs === 1 ? "" : "s"} ago`;
  const days = Math.floor(hrs / 24);
  return `${days} day${days === 1 ? "" : "s"} ago`;
}
