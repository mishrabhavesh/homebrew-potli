import React, { useEffect, useState } from "react";
import { useUiStore } from "../stores/uiStore";

interface Snapshot {
  screenRecording: string;
  accessibility: string;
  platform: string;
}

export function Permissions() {
  const [snapshot, setSnapshot] = useState<Snapshot | null>(null);
  const platform = useUiStore((s) => s.platform);

  const refresh = () => window.copyclip.permissions.get().then(setSnapshot);

  useEffect(() => {
    refresh();
    const onFocus = () => refresh();
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, []);

  const isMac = platform === "darwin";

  return (
    <div className="mx-auto max-w-xl px-8 py-8">
      <h1 className="mb-2 text-[17px] font-semibold tracking-tight">Permissions</h1>
      <p className="mb-6 text-[12.5px] text-[#9c9ca3]">
        CopyClip only asks for what the primary workflow actually needs.
      </p>

      {!isMac ? (
        <div className="panel p-5">
          <p className="text-[13px] font-medium">No extra permissions required</p>
          <p className="mt-1.5 text-[12.5px] leading-relaxed text-[#6b6b70] dark:text-[#9c9ca3]">
            On {platform === "win32" ? "Windows" : "Linux"}, screen capture works out of the box. If you enable
            &ldquo;Copy and paste automatically&rdquo;, your desktop environment may show its own prompt the first
            time a keystroke is simulated.
          </p>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          <PermissionCard
            title="Screen Recording"
            description="Required to capture the area of your screen."
            status={snapshot?.screenRecording ?? "not-determined"}
            onOpenSettings={() => window.copyclip.permissions.openSettings("screen-recording")}
          />
          <PermissionCard
            title="Accessibility"
            description='Only needed if "Copy and paste automatically" is enabled — lets CopyClip simulate a paste keystroke.'
            status={snapshot?.accessibility ?? "not-determined"}
            onOpenSettings={() => window.copyclip.permissions.openSettings("accessibility")}
          />
        </div>
      )}
    </div>
  );
}

function PermissionCard({
  title,
  description,
  status,
  onOpenSettings
}: {
  title: string;
  description: string;
  status: string;
  onOpenSettings: () => void;
}) {
  const granted = status === "granted";
  return (
    <div className="panel p-5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <p className="text-[13px] font-medium">{title}</p>
            <StatusPill granted={granted} status={status} />
          </div>
          <p className="mt-1.5 max-w-sm text-[12.5px] leading-relaxed text-[#6b6b70] dark:text-[#9c9ca3]">{description}</p>
        </div>
        {!granted && (
          <button className="btn-secondary shrink-0 text-[12px]" onClick={onOpenSettings}>
            Open System Settings
          </button>
        )}
      </div>
    </div>
  );
}

function StatusPill({ granted, status }: { granted: boolean; status: string }) {
  return (
    <span
      className={`rounded-full px-2 py-0.5 text-[10.5px] font-medium ${
        granted ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" : "bg-amber-500/10 text-amber-600 dark:text-amber-400"
      }`}
    >
      {granted ? "Granted" : status === "denied" ? "Denied" : "Not granted"}
    </span>
  );
}
