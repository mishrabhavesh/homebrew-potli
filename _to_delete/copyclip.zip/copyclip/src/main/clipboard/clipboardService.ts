import { clipboard } from "electron";
import { logger } from "../logger";

/**
 * Thin wrapper over Electron's clipboard module. Kept as its own module so
 * call sites don't reach into `electron` directly, and so we have one place
 * to add safety behavior later (e.g. clearing sensitive clipboard entries).
 *
 * Per spec §18: never log clipboard contents.
 */
export const clipboardService = {
  writeText(text: string): void {
    try {
      clipboard.writeText(text);
    } catch (error) {
      logger.error("Failed to write to clipboard", error);
      throw new Error("Could not copy text to the clipboard.");
    }
  },

  readText(): string {
    return clipboard.readText();
  }
};
