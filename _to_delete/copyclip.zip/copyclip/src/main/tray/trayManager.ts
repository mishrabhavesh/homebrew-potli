import { Tray, Menu, nativeImage, MenuItemConstructorOptions } from "electron";
import path from "node:path";
import { APP_NAME } from "../../shared/constants";
import { settingsStore } from "../settings/settingsStore";
import { shortcutManager } from "../shortcuts/shortcutManager";
import { showMainWindow } from "../windows/mainWindow";
import { humanizeAccelerator } from "../../shared/shortcut/humanize";
import { bundledResourcesPath } from "../paths";

let tray: Tray | null = null;

function resolveTrayIconPath(): string {
  const filename = process.platform === "darwin" ? "trayIconTemplate.png" : "trayIcon.png";
  return path.join(bundledResourcesPath(), filename);
}

export function createTray(handlers: {
  onExtractText: () => void;
  onOpenHistory: () => void;
  onOpenSettings: () => void;
  onQuit: () => void;
}): Tray {
  if (tray) return tray;

  let image = nativeImage.createFromPath(resolveTrayIconPath());
  if (image.isEmpty()) {
    // Fallback: a minimal generated glyph so the app never ships with a blank tray icon.
    image = nativeImage.createEmpty();
  }
  if (process.platform === "darwin") {
    image = image.resize({ width: 18, height: 18 });
    image.setTemplateImage(true);
  }

  tray = new Tray(image);
  tray.setToolTip(APP_NAME);

  rebuildMenu(handlers);

  settingsStore.onChange(() => rebuildMenu(handlers));

  tray.on("click", () => {
    if (process.platform !== "darwin") {
      // On Windows/Linux a plain click commonly toggles the app; on macOS the
      // menu bar convention is to always show the dropdown menu instead.
      showMainWindow("quick-capture");
    }
  });

  return tray;

  function rebuildMenu(h: typeof handlers): void {
    if (!tray) return;
    const accel = humanizeAccelerator(settingsStore.get("shortcut"), process.platform);
    const paused = shortcutManager.isPaused();

    const template: MenuItemConstructorOptions[] = [
      { label: APP_NAME, enabled: false },
      { type: "separator" },
      { label: `Extract Text${accel ? `   ${accel}` : ""}`, click: h.onExtractText, enabled: !paused },
      { type: "separator" },
      { label: "History", click: h.onOpenHistory },
      { label: "Settings", click: h.onOpenSettings },
      { type: "separator" },
      {
        label: "Pause Shortcut",
        type: "checkbox",
        checked: paused,
        click: () => {
          const next = !shortcutManager.isPaused();
          shortcutManager.setPaused(next);
          settingsStore.update({ shortcutPaused: next });
        }
      },
      { type: "separator" },
      { label: `Quit ${APP_NAME}`, click: h.onQuit, role: "quit" }
    ];

    tray.setContextMenu(Menu.buildFromTemplate(template));
  }
}

export function getTray(): Tray | null {
  return tray;
}

export function destroyTray(): void {
  tray?.destroy();
  tray = null;
}
