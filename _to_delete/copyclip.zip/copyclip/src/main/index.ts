import { app, BrowserWindow } from "electron";
import { createMainWindow, showMainWindow } from "./windows/mainWindow";
import { closeSelectionOverlays, openSelectionOverlays } from "./windows/overlayWindow";
import { createTray, destroyTray } from "./tray/trayManager";
import { shortcutManager } from "./shortcuts/shortcutManager";
import { settingsStore } from "./settings/settingsStore";
import { registerIpcHandlers } from "./ipc/registerIpcHandlers";
import { ocrService } from "./ocr/ocrService";
import { isCaptureInFlight } from "./capture/captureFlow";
import { logger } from "./logger";
import { APP_NAME } from "../shared/constants";

app.setName(APP_NAME);

// Only one instance of a background utility like this should ever run.
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on("second-instance", () => {
    showMainWindow("quick-capture");
  });

  app.whenReady().then(bootstrap);
}

async function bootstrap(): Promise<void> {
  registerIpcHandlers();

  // This is a background/menu-bar-style utility: no Dock icon on macOS, and
  // closing the main window (see mainWindow.ts) hides rather than quits.
  if (process.platform === "darwin") {
    app.dock?.hide();
  }

  const settings = settingsStore.getAll();

  shortcutManager.setTriggerHandler(() => {
    if (isCaptureInFlight()) return;
    openSelectionOverlays();
  });
  shortcutManager.setPaused(settings.shortcutPaused);
  const registration = shortcutManager.register(settings.shortcut);
  if (!registration.success) {
    logger.warn(`Could not register saved shortcut "${settings.shortcut}": ${registration.error}`);
  }

  createTray({
    onExtractText: () => {
      if (!isCaptureInFlight()) openSelectionOverlays();
    },
    onOpenHistory: () => showMainWindow("history"),
    onOpenSettings: () => showMainWindow("settings-keyboard"),
    onQuit: () => {
      (app as unknown as { isQuitting: boolean }).isQuitting = true;
      app.quit();
    }
  });

  if (!settings.onboardingComplete) {
    createMainWindow("onboarding");
  }

  app.on("activate", () => {
    // Only relevant on macOS with a Dock icon, which we hide — kept for
    // correctness if a future build re-enables the Dock icon.
    if (BrowserWindow.getAllWindows().length === 0) {
      createMainWindow();
    } else {
      showMainWindow();
    }
  });
}

app.on("window-all-closed", () => {
  // Background utility: never quit just because windows closed. macOS also
  // conventionally never quits on this event; we extend that to all platforms
  // since the app's whole purpose is to keep running in the tray.
});

app.on("before-quit", () => {
  (app as unknown as { isQuitting: boolean }).isQuitting = true;
  shortcutManager.unregisterAll();
  closeSelectionOverlays();
  destroyTray();
  void ocrService.dispose();
});

process.on("uncaughtException", (error) => {
  logger.error("Uncaught exception in main process", error);
});
