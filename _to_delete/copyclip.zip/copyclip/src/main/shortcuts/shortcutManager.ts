import { globalShortcut } from "electron";
import { validateAccelerator } from "../../shared/shortcut/validateAccelerator";
import { logger } from "../logger";

export interface RegisterResult {
  success: boolean;
  error?: string;
}

/**
 * Owns the single global shortcut registration for the app. Electron only lets
 * one accelerator map to one callback at a time process-wide, so this class is
 * the sole owner of globalShortcut calls — nothing else in the app should call
 * globalShortcut directly.
 */
class ShortcutManager {
  private currentAccelerator: string | null = null;
  private paused = false;
  private onTrigger: (() => void) | null = null;

  setTriggerHandler(handler: () => void): void {
    this.onTrigger = handler;
  }

  register(accelerator: string): RegisterResult {
    const validation = validateAccelerator(accelerator);
    if (!validation.valid) {
      return { success: false, error: validation.error };
    }

    this.unregisterCurrent();

    if (this.paused) {
      // Remember the accelerator but don't actually bind it while paused.
      this.currentAccelerator = accelerator;
      return { success: true };
    }

    try {
      const ok = globalShortcut.register(accelerator, () => {
        this.onTrigger?.();
      });
      if (!ok) {
        return {
          success: false,
          error: "This shortcut is already used by another application. Try a different combination."
        };
      }
      this.currentAccelerator = accelerator;
      return { success: true };
    } catch (error) {
      logger.error("Failed to register global shortcut", error);
      return { success: false, error: "This shortcut could not be registered on your system." };
    }
  }

  unregisterCurrent(): void {
    if (this.currentAccelerator) {
      try {
        globalShortcut.unregister(this.currentAccelerator);
      } catch {
        // ignore — accelerator may already be unregistered
      }
    }
  }

  setPaused(paused: boolean): void {
    this.paused = paused;
    if (paused) {
      this.unregisterCurrent();
    } else if (this.currentAccelerator) {
      this.register(this.currentAccelerator);
    }
  }

  isPaused(): boolean {
    return this.paused;
  }

  getCurrent(): string | null {
    return this.currentAccelerator;
  }

  unregisterAll(): void {
    globalShortcut.unregisterAll();
  }
}

export const shortcutManager = new ShortcutManager();
