import Store from "electron-store";
import { randomUUID } from "node:crypto";
import { HistoryItem } from "../../shared/types/history";
import { HISTORY_LIMIT } from "../../shared/constants";

interface HistorySchema {
  items: HistoryItem[];
}

type Listener = (items: HistoryItem[]) => void;

/**
 * Local-only OCR history. Per spec §13/§18: never leaves the device, is not
 * logged, and only stores the text results (never the screenshot image).
 */
class HistoryStore {
  private store: Store<HistorySchema>;
  private listeners = new Set<Listener>();

  constructor() {
    this.store = new Store<HistorySchema>({
      name: "history",
      defaults: { items: [] }
    });
  }

  getAll(): HistoryItem[] {
    return this.store.get("items", []);
  }

  add(entry: Omit<HistoryItem, "id" | "createdAt">): HistoryItem {
    const item: HistoryItem = {
      ...entry,
      id: randomUUID(),
      createdAt: new Date().toISOString()
    };
    const items = [item, ...this.getAll()].slice(0, HISTORY_LIMIT);
    this.store.set("items", items);
    this.emit(items);
    return item;
  }

  delete(id: string): void {
    const items = this.getAll().filter((i) => i.id !== id);
    this.store.set("items", items);
    this.emit(items);
  }

  clear(): void {
    this.store.set("items", []);
    this.emit([]);
  }

  onChange(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private emit(items: HistoryItem[]): void {
    for (const listener of this.listeners) listener(items);
  }
}

export const historyStore = new HistoryStore();
